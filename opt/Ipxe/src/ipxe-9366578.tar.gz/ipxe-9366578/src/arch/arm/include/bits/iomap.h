#ifndef _BITS_IOMAP_H
#define _BITS_IOMAP_H

/** @file
 *
 * ARM-specific I/O mapping API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#endif /* _BITS_IOMAP_H */
