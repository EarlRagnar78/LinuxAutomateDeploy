#ifndef _BITS_UART_H
#define _BITS_UART_H

/** @file
 *
 * 16550-compatible UART
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#endif /* _BITS_UART_H */
